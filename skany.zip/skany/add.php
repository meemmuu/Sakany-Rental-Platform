<?php
  include 'includes/db.php';
  include 'includes/i18n.php';
  $errors = array();

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $owner_name  = $conn->real_escape_string($_POST['owner_name'] ?? '');
    $phone       = $conn->real_escape_string($_POST['phone'] ?? '' );
    $title       = $conn->real_escape_string($_POST['title'] ?? '');
    $description = $conn->real_escape_string($_POST['description'] ?? '');
    $governorate = $conn->real_escape_string($_POST['governorate'] ?? '');
    $city        = $conn->real_escape_string($_POST['city'] ?? '');
    $price       = floatval($_POST['price'] ?? 0);
    $video_file_name = '';

    if (isset($_FILES['video_file']) && $_FILES['video_file']['error'] === 0) {
      $allowed = ['mp4','webm','ogg','mov'];
      $fn  = $_FILES['video_file']['name'];
      $ext = strtolower(pathinfo($fn, PATHINFO_EXTENSION));
      if (in_array($ext, $allowed)) {
        $target_dir = 'uploads/videos/';
        if (!is_dir($target_dir)) mkdir($target_dir, 0755, true);
        $target = $target_dir . time() . '_' . basename($fn);
        if (move_uploaded_file($_FILES['video_file']['tmp_name'], $target)) {
          $video_file_name = basename($target);
        } else {
          $errors[] = 'Failed to upload video.';
        }
      } else {
        $errors[] = 'Unsupported video format.';
      }
    }

    if (empty($owner_name) || empty($phone) || empty($title)) {
      $errors[] = 'Please fill required fields.';
    }

    if (empty($errors)) {
      $stmt = $conn->prepare("INSERT INTO apartments (owner_name,phone,title,description,governorate,city,price,video_file) VALUES (?,?,?,?,?,?,?,?)");
      $stmt->bind_param('sssssdss', $owner_name, $phone, $title, $description, $governorate, $city, $price, $video_file_name);
      $stmt->execute();
      header('Location: index.php');
      exit;
    }
  }
?>

<!doctype html>
<html lang="<?php echo htmlspecialchars($t['lang_code']); ?>" dir="<?php echo htmlspecialchars($dir); ?>">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo htmlspecialchars(t('add_listing')); ?> - Sakny</title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="topbar">
      <div class="container navrow">
        <div class="brand"><div class="logo">Sakny</div></div>
        <nav class="nav">
          <a href="index.php"><?php echo htmlspecialchars(t('home')); ?></a>
          <a href="contact.php"><?php echo htmlspecialchars(t('contact')); ?></a>
          <a href="?lang=<?php echo $lang==='ar'?'en':'ar'; ?>" style="margin-left:12px"><?php echo $lang==='ar'?'EN':'AR'; ?></a>
        </nav>
      </div>
    </header>

    <main class="container">
      <h2><?php echo htmlspecialchars(t('add_your_listing')); ?></h2>
      <?php if (!empty($errors)) { echo '<div class="errors"><ul>'; foreach ($errors as $e) echo '<li>'.htmlspecialchars($e).'</li>'; echo '</ul></div>'; } ?>

      <form method="post" enctype="multipart/form-data" class="form-grid">
        <label><?php echo htmlspecialchars(t('owner_name')); ?></label>
        <input name="owner_name" required maxlength="100" />

        <label><?php echo htmlspecialchars(t('phone')); ?></label>
        <input name="phone" required maxlength="11" />

        <label><?php echo htmlspecialchars(t('title')); ?></label>
        <input name="title" required maxlength="150" />

        <label><?php echo htmlspecialchars(t('description')); ?></label>
        <textarea name="description" maxlength="1000"></textarea>

        <label for="govSelect"><?php echo htmlspecialchars(t('governorate')); ?></label>
        <select id="govSelect" name="governorate" required onchange="if(window.populateCities){ populateCities(this.value); } else if(window.updateCities){ updateCities(); }">
          <option value="" disabled selected><?php echo $lang==='ar'?'اختر المحافظة':'Select governorate'; ?></option>
          <?php
            $loc_path = __DIR__ . '/assets/data/eg_locations.json';
            $loc_rel  = 'assets/data/eg_locations.json';
            // resolve relative from project root
            $json_file = file_exists($loc_path) ? $loc_path : (file_exists($loc_rel) ? $loc_rel : null);
            $gov_list = array();
            if ($json_file) {
              $json = @file_get_contents($json_file);
              if ($json !== false) {
                $arr = json_decode($json, true);
                if (is_array($arr)) {
                  $dataset = $arr[$lang] ?? $arr['en'] ?? $arr;
                  if (is_array($dataset)) $gov_list = array_keys($dataset);
                }
              }
            }
            if (empty($gov_list)) { $gov_list = $lang==='ar' ? array('القاهرة','الجيزة') : array('Cairo','Giza'); }
            sort($gov_list);
            foreach ($gov_list as $g) {
              echo '<option value="'.htmlspecialchars($g).'">'.htmlspecialchars($g)."</option>"; }
          ?>
        </select>

        <label for="citySelect"><?php echo htmlspecialchars(t('city')); ?></label>
        <select id="citySelect" name="city" required>
          <option value="" disabled selected><?php echo $lang==='ar'?'اختر المدينة أو المركز':'Select city/center'; ?></option>
        </select>


        <label><?php echo htmlspecialchars(t('price_egp')); ?></label>
        <input name="price" type="number" step="0.01" />

        <label><?php echo htmlspecialchars(t('upload_video_opt')); ?></label>
        <input type="file" name="video_file" accept="video/*" />

        <div style="grid-column:1/-1">
          <button class="btn primary" type="submit"><?php echo htmlspecialchars(t('publish_listing')); ?></button>
        </div>
      </form>
    </main>

    <footer class="foot"><div class="container">© <?php echo date('Y'); ?> Sakny</div></footer>
    <script src="assets/js/main.js?v=<?php echo time();?>"></script>
  </body>
</html>
