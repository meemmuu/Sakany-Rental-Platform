<?php include 'includes/db.php'; include 'includes/i18n.php'; ?>

<!doctype html>
<html lang="<?php echo htmlspecialchars($t['lang_code']); ?>" dir="<?php echo htmlspecialchars($dir); ?>">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo htmlspecialchars(t('contact')); ?> — <?php echo htmlspecialchars(t('site_name')); ?></title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="topbar">
      <div class="container navrow">
        <div class="brand">
          <div class="logo"><?php echo htmlspecialchars(t('site_name')); ?></div>
          <div class="tag"><?php echo htmlspecialchars(t('brand_tag')); ?></div>
        </div>
        <nav class="nav">
          <a href="index.php#home"><?php echo htmlspecialchars(t('home')); ?></a>
          <a href="add.php" class="cta"><?php echo htmlspecialchars(t('add_listing')); ?></a>
          <a href="contact.php"><?php echo htmlspecialchars(t('contact')); ?></a>
          <a href="?lang=<?php echo $lang==='ar'?'en':'ar'; ?>" style="margin-left:12px"><?php echo $lang==='ar'?'EN':'AR'; ?></a>
        </nav>
      </div>
    </header>

    <main>
      <section id="contact" class="contact container">
        <h2><?php echo htmlspecialchars(t('contact_title')); ?></h2>
        <div class="contact-grid">
          <div class="card contact-form">
            <form id="contactForm" onsubmit="return handleContact(event);">
              <div class="form-inline">
                <div class="inline-field">
                  <label for="cname"><?php echo $lang==='ar'?'الاسم':'Name'; ?></label>
                  <input id="cname" placeholder="Your name" required />
                </div>
                <div class="inline-field">
                  <label for="cemail">Email</label>
                  <input id="cemail" type="email" placeholder="you@example.com" required />
                </div>
                <div class="inline-field full">
                  <label for="cmsg"><?php echo $lang==='ar'?'الرسالة':'Message'; ?></label>
                  <textarea id="cmsg" placeholder="Write your message" required></textarea>
                </div>
                <button class="btn primary" type="submit"><?php echo htmlspecialchars(t('send_message')); ?></button>
              </div>
            </form>
            <div id="contactResult"></div>
          </div>
          <aside class="card contact-info">
            <p>Phone: +20 123 456 7890</p>
            <p>Email:mo@gmail.com</p>
          </aside>
        </div>
      </section>
    </main>

    <footer class="foot"><div class="container">©<?php echo date('Y'); ?> <?php echo htmlspecialchars(t('site_name')); ?></div></footer>
    <script src="assets/js/main.js"></script>
  </body>
</html>
