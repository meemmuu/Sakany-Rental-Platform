<?php
  include 'includes/db.php';
  include 'includes/i18n.php';
  $id  = intval($_GET['id'] ?? 0);
  $res = $conn->query("SELECT * FROM apartments WHERE id=$id");
  if ($res->num_rows == 0) { echo 'Listing not found.'; exit; }
  $row = $res->fetch_assoc();
?>

<!doctype html>
<html lang="<?php echo htmlspecialchars($t['lang_code']); ?>" dir="<?php echo htmlspecialchars($dir); ?>">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title><?php echo htmlspecialchars($row['title']); ?> — <?php echo htmlspecialchars(t('site_name')); ?></title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="topbar">
      <div class="container navrow">
        <div class="brand">
          <div class="logo"><?php echo htmlspecialchars(t('site_name')); ?></div>
          <div class="tag"><?php echo htmlspecialchars(t('brand_tag')); ?></div>
        </div>
        <nav class="nav">
          <a href="index.php#home"><?php echo htmlspecialchars(t('home')); ?></a>
          <a href="add.php" class="cta"><?php echo htmlspecialchars(t('add_listing')); ?></a>
          <a href="contact.php"><?php echo htmlspecialchars(t('contact')); ?></a>
          <a href="?lang=<?php echo $lang==='ar'?'en':'ar'; ?>" style="margin-left:12px"><?php echo $lang==='ar'?'EN':'AR'; ?></a>
        </nav>
      </div>
    </header>

    <main class="container single">
      <div class="single-left card">
        <?php if (!empty($row['video_file']) && file_exists('uploads/videos/' . $row['video_file'])): ?>
          <video controls src="uploads/videos/<?php echo htmlspecialchars($row['video_file']); ?>" style="width:100%;height:auto"></video>
        <?php else: ?>
          <div class="img-placeholder" style="height:320px"></div>
        <?php endif; ?>

        <h2><?php echo htmlspecialchars($row['title']); ?></h2>
        <p class="meta"><?php echo htmlspecialchars($row['governorate'] . ' - ' . $row['city']); ?></p>
        <p class="price"><?php echo number_format($row['price'], 2); ?> EGP</p>
        <p><?php echo nl2br(htmlspecialchars($row['description'])); ?></p>
      </div>

      <aside class="single-right card">
        <h3><?php echo htmlspecialchars(t('owner')); ?></h3>
        <p><?php echo htmlspecialchars($row['owner_name']); ?></p>
        <p><?php echo htmlspecialchars(t('phone')); ?>: <a href="tel:<?php echo htmlspecialchars($row['phone']); ?>"><?php echo htmlspecialchars($row['phone']); ?></a></p>
      </aside>
    </main>

    <footer class="foot"><div class="container">©<?php echo date('Y'); ?> <?php echo htmlspecialchars(t('site_name')); ?></div></footer>
    <script src="assets/js/main.js"></script>
  </body>
</html>
