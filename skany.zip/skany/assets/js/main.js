document.addEventListener('DOMContentLoaded', function(){
  // simple play on hover for videos
  document.querySelectorAll('video').forEach(v=>{
    v.addEventListener('mouseenter', ()=>{ try{ v.play(); v.muted=false;}catch(e){} });
    v.addEventListener('mouseleave', ()=>{ try{ v.pause(); v.muted=true; v.currentTime=0;}catch(e){} });
  });
  // Dependent selects for Governorate -> City on add.php
  (function(){
    var govSel = document.getElementById('govSelect');
    var citySel = document.getElementById('citySelect');
    if(!govSel || !citySel) return;
    var pageLang = (document.documentElement.getAttribute('lang') || 'en').toLowerCase();
    // Inline bilingual dataset to avoid any fetch issues
    var LOC = {
      en: {
        "Cairo": ["Nasr City", "Heliopolis", "New Cairo", "Maadi", "Helwan", "Shubra", "Ain Shams", "El Marg", "El Salam", "El Shorouk", "Badr", "15 May"],
        "Giza": ["Dokki", "Mohandessin", "Imbaba", "Agouza", "Haram", "Faisal", "6th of October", "Sheikh Zayed", "Kerdasa", "Bulaq El Dakrour"],
        "Alexandria": ["Montaza", "Smouha", "Sidi Gaber", "Amreya", "Al Agamy", "Gomrok", "Labban", "Dekhela", "Borg El Arab"],
        "Qalyubia": ["Banha", "Qalyub", "Shubra El Kheima", "Khosous", "Toukh", "Qanater", "Kafr Shukr", "Shebin El Qanater", "Khanka"],
        "Sharqia": ["Zagazig", "Bilbeis", "Abu Hammad", "Abu Kabir", "Hehia", "Kafr Saqr", "El Husseiniya", "Faqous", "Al Qurein", "Ain Shams Center"],
        "Gharbia": ["Tanta", "El Mahalla El Kubra", "Kafr El Zayat", "Zefta", "Basion", "Samanoud", "Qutour"],
        "Monufia": ["Shibin El Kom", "Menouf", "Ashmoun", "Tala", "El Bagour", "Quesna", "Sers El Lyan", "Berket El Sabaa"],
        "Dakahlia": ["Mansoura", "Talkha", "Mit Ghamr", "Aga", "Dikirnis", "Shirbin", "Belqas", "El Sinbellawein"],
        "Beheira": ["Damanhour", "Kafr El Dawwar", "Rashid", "Edku", "Abu Hummus", "Kom Hamada", "Itay El Barud", "El Mahmoudia"],
        "Kafr El Sheikh": ["Kafr El Sheikh", "Desouk", "Fuwa", "Sidi Salem", "Qallin", "Baltim", "Biyala", "Mitte El Amel"],
        "Damietta": ["Damietta", "New Damietta", "Faraskur", "Kafr Saad", "Zarqa", "Ras El Bar"],
        "Port Said": ["Port Said", "Port Fouad", "El Arab", "El Manakh", "El Dawahy"],
        "Ismailia": ["Ismailia", "Fayed", "Tell El Kebir", "Qantara Gharb", "Qantara Sharq"],
        "Suez": ["Suez", "Ataqah", "Faisal", "Arbaeen", "Suez New"],
        "North Sinai": ["Arish", "Sheikh Zuweid", "Rafah", "Bir El Abd", "Hasna", "Nakhl"],
        "South Sinai": ["Sharm El Sheikh", "Dahab", "Nuweiba", "Taba", "St. Catherine", "El Tor", "Abu Rudeis", "Ras Sudr"],
        "Red Sea": ["Hurghada", "Safaga", "Quseer", "Marsa Alam", "Ras Gharib", "Shalateen", "Halaib"],
        "Fayoum": ["Fayoum", "Tamiya", "Itsa", "Sinnuris", "Ibshway", "Yousef El Seddik"],
        "Beni Suef": ["Beni Suef", "El Wasta", "Nasser", "Ihnasya", "Beba", "Fashn", "Sumusta El Waqf"],
        "Minya": ["Minya", "Abu Qurqas", "Mallawi", "Deir Mawas", "Maghagha", "Beni Mazar", "Samalout", "Matay"],
        "Assiut": ["Assiut", "Dairut", "Qusiya", "Manfalut", "Abnoub", "El Badari", "Sahel Selim", "El Ghanayem"],
        "Sohag": ["Sohag", "Akhmim", "Girga", "Tahta", "Tema", "El Maragha", "Dar El Salam", "Juhayna"],
        "Qena": ["Qena", "Qus", "Nag Hammadi", "Deshna", "Farshut", "Abu Tesht", "Naqada"],
        "Luxor": ["Luxor", "Armant", "Esna", "Al Tud", "El Bayadeya"],
        "Aswan": ["Aswan", "Kom Ombo", "Edfu", "Daraw", "Abu Simbel", "Nasr El Nuba"],
        "New Valley": ["Kharga", "Dakhla", "Farafra", "Balat", "Baris"],
        "Matrouh": ["Marsa Matrouh", "El Alamein", "Siwa", "El Dabaa", "Hammam", "Barani", "Salloum"]
      },
      ar: {
        "القاهرة": ["مدينة نصر", "مصر الجديدة", "القاهرة الجديدة", "المعادي", "حلوان", "شبرا", "عين شمس", "المرج", "السلام", "الشروق", "بدر", "15 مايو"],
        "الجيزة": ["الدقي", "المهندسين", "إمبابة", "العجوزة", "الهرم", "فيصل", "6 أكتوبر", "الشيخ زايد", "كرداسة", "بولاق الدكرور"],
        "الإسكندرية": ["المنتزه", "سموحة", "سيدي جابر", "العامرية", "العجمي", "الجمرك", "لبان", "الدخيلة", "برج العرب"],
        "القليوبية": ["بنها", "قليوب", "شبرا الخيمة", "الخصوص", "طوخ", "القناطر", "كفر شكر", "شبين القناطر", "الخانكة"],
        "الشرقية": ["الزقازيق", "بلبيس", "أبو حماد", "أبو كبير", "ههيا", "كفر صقر", "الحسينية", "فاقوس", "القرين"],
        "الغربية": ["طنطا", "المحلة الكبرى", "كفر الزيات", "زفتى", "بسيون", "سمنود", "قطور"],
        "المنوفية": ["شبين الكوم", "منوف", "أشمون", "تلا", "الباجور", "قويسنا", "سرس الليان", "بركة السبع"],
        "الدقهلية": ["المنصورة", "طلخا", "ميت غمر", "أجا", "دكرنس", "شربين", "بلقاس", "السنبلاوين"],
        "البحيرة": ["دمنهور", "كفر الدوار", "رشيد", "إدكو", "أبو حمص", "كوم حمادة", "إيتاي البارود", "المحمودية"],
        "كفر الشيخ": ["كفر الشيخ", "دسوق", "فوه", "سيدي سالم", "قلين", "بلطيم", "بيلا"],
        "دمياط": ["دمياط", "دمياط الجديدة", "فارسكور", "كفر سعد", "الزرقا", "رأس البر"],
        "بورسعيد": ["بورسعيد", "بورفؤاد", "العرب", "المناخ", "الضواحي"],
        "الإسماعيلية": ["الإسماعيلية", "فايد", "التل الكبير", "القنطرة غرب", "القنطرة شرق"],
        "السويس": ["السويس", "عتاقة", "فيصل", "الأربعين", "السويس الجديدة"],
        "شمال سيناء": ["العريش", "الشيخ زويد", "رفح", "بئر العبد", "الحسنة", "نخل"],
        "جنوب سيناء": ["شرم الشيخ", "دهب", "نويبع", "طابا", "سانت كاترين", "الطور", "أبو رديس", "رأس سدر"],
        "البحر الأحمر": ["الغردقة", "سفاجا", "القصير", "مرسى علم", "رأس غارب", "الشلاتين", "حلايب"],
        "الفيوم": ["الفيوم", "طامية", "إطسا", "سنورس", "إبشواي", "يوسف الصديق"],
        "بني سويف": ["بني سويف", "الواسطى", "ناصر", "إهناسيا", "ببا", "الفشن", "سمسطا"],
        "المنيا": ["المنيا", "أبو قرقاص", "ملوي", "دير مواس", "مغاغة", "بني مزار", "سمالوط", "مطاي"],
        "أسيوط": ["أسيوط", "ديروط", "القوصية", "منفلوط", "أبنوب", "البداري", "ساحل سليم", "الغنايم"],
        "سوهاج": ["سوهاج", "أخميم", "جرجا", "طهطا", "طهطا", "المراغة", "دار السلام", "جهينة"],
        "قنا": ["قنا", "قفط", "نجع حمادي", "دشنا", "فرشوط", "أبو تشت", "نقادة"],
        "الأقصر": ["الأقصر", "أرمنت", "إسنا", "الطود", "البياضية"],
        "أسوان": ["أسوان", "كوم أمبو", "إدفو", "دراو", "أبو سمبل", "نصر النوبة"],
        "الوادي الجديد": ["الخارجة", "الداخلة", "الفرافرة", "بلاط", "باريس"],
        "مطروح": ["مرسى مطروح", "العلمين", "سيوة", "الضبعة", "الحمام", "برانى", "السلوم"]
      }
    };
    var dataset = LOC[pageLang] || LOC.en;
    // expose for quick debugging if needed
    window.LOC = LOC;
    // fill governors only if not already rendered server-side
    if ((govSel.options || []).length <= 1) {
      var govs = Object.keys(dataset || {});
      govs.sort().forEach(function(g){
        var opt = document.createElement('option');
        opt.value = g; opt.textContent = g; govSel.appendChild(opt);
      });
    }
    var norm = function(s){ return (s||'').toString().trim().toLowerCase().replace(/\s+/g,' '); };

    var updateCities = function(){
      var placeholder = pageLang==='ar' ? 'اختر المدينة أو المركز' : 'Select city/center';
      var g = (govSel.value || '').trim();
      if (!g && govSel.selectedOptions && govSel.selectedOptions[0]) {
        g = (govSel.selectedOptions[0].value || govSel.selectedOptions[0].text || '').trim();
      }
      var baseOpt = '<option value="" disabled selected>'+placeholder+'</option>';
      citySel.innerHTML = baseOpt;
      citySel.disabled = true;
      if(!g){ return; }
      var list = [];
      if (dataset[g]) {
        list = (dataset[g] && dataset[g].slice) ? dataset[g].slice() : [];
      } else {
        // try case-insensitive match
        var gNorm = norm(g);
        var keyMatch = Object.keys(dataset).find(function(k){ return norm(k) === gNorm; });
        if (!keyMatch && alias[gNorm]) { keyMatch = alias[gNorm]; }
        if (keyMatch && dataset[keyMatch]) list = (dataset[keyMatch].slice) ? dataset[keyMatch].slice() : [];
      }
      if (!list || list.length === 0) {
        // last-resort: show merged cities from all governorates so user can proceed
        var merged = [];
        Object.keys(dataset).forEach(function(k){ if (Array.isArray(dataset[k])) merged = merged.concat(dataset[k]); });
        list = Array.from(new Set(merged)).sort();
      }
      var html = baseOpt;
      list.sort().forEach(function(c){ html += '<option value="'+c.replace(/"/g,'&quot;')+'">'+c.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</option>'; });
      citySel.innerHTML = html;
      citySel.value = '';
      citySel.disabled = false;
      if (citySel.options.length <= 1) { try{ console.warn('No cities populated for', g); }catch(e){} }
    };
    ['change','input','keyup','blur'].forEach(function(ev){ govSel.addEventListener(ev, updateCities); });
    // Ensure cities are in sync on load
    if (govSel.value) { updateCities(); }
    // expose for inline fallback AFTER function is defined
    window.updateCities = updateCities;
  })();
  // Global utility in case inline onchange calls it directly
  window.populateCities = function(govName){
    var citySel = document.getElementById('citySelect');
    var govSel  = document.getElementById('govSelect');
    if(!citySel){ return; }
    var pageLang = (document.documentElement.getAttribute('lang') || 'en').toLowerCase();
    var LOC = window.LOC;
    if(!LOC){ return; }
    var dataset = LOC[pageLang] || LOC.en || {};
    var placeholder = pageLang==='ar' ? 'اختر المدينة أو المركز' : 'Select city/center';
    var baseOpt = '<option value="" disabled selected>'+placeholder+'</option>';
    citySel.innerHTML = baseOpt; citySel.disabled = true;
    var g = (govName || (govSel && govSel.value) || '').trim();
    if(!g){ return; }
    var norm = function(s){ return (s||'').toString().trim().toLowerCase().replace(/\s+/g,' '); };
    var list = dataset[g];
    if(!Array.isArray(list)){
      var keyMatch = Object.keys(dataset).find(function(k){ return norm(k)===norm(g); });
      if (keyMatch) list = dataset[keyMatch];
    }
    if(!Array.isArray(list)) return;
    var html = baseOpt;
    list.slice().sort().forEach(function(c){ html += '<option value="'+c.replace(/"/g,'&quot;')+'">'+c.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</option>'; });
    citySel.innerHTML = html; citySel.disabled = false; citySel.value='';
  };
  window.handleContact = function(e){
    e.preventDefault();
    var n=document.getElementById('cname').value, em=document.getElementById('cemail').value, m=document.getElementById('cmsg').value;
    var out=document.getElementById('contactResult');
    if(!n||!em||!m){ out.textContent='Please fill the form.'; return false; }
    out.textContent='Thanks '+n+'. This is a demo contact form.';
    document.getElementById('cname').value='';document.getElementById('cemail').value='';document.getElementById('cmsg').value='';
    return false;
  };
  // Toggle owner contact box on listing cards
  window.toggleOwner = function(id){
    var el = document.getElementById(id);
    if(!el) return;
    var cur = (el.style.display||'').toLowerCase();
    el.style.display = (cur === 'none' || cur === '') ? 'block' : 'none';
  };
});
