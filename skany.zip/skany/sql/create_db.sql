CREATE DATABASE IF NOT EXISTS rentease_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rentease_db;
CREATE TABLE IF NOT EXISTS apartments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  owner_name VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  title VARCHAR(200) NOT NULL,
  description TEXT,
  governorate VARCHAR(100),
  city VARCHAR(100),
  address_text VARCHAR(255),
  price DECIMAL(10,2) DEFAULT 0,
  rooms INT DEFAULT 0,
  bathrooms INT DEFAULT 0,
  furnished ENUM('Yes','No') DEFAULT 'No',
  family_only ENUM('Yes','No') DEFAULT 'No',
  video_file VARCHAR(255) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
