<?php include 'includes/db.php'; include 'includes/i18n.php'; ?>

<!doctype html>
<html lang="<?php echo htmlspecialchars($t['lang_code']); ?>" dir="<?php echo htmlspecialchars($dir); ?>">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?php echo htmlspecialchars(t('site_name')); ?> — <?php echo htmlspecialchars(t('brand_tag')); ?></title>
    <link rel="stylesheet" href="assets/css/style.css" />
  </head>
  <body>
    <header class="topbar">
      <div class="container navrow">
        <div class="brand">
          <div class="logo"><?php echo htmlspecialchars(t('site_name')); ?></div>
          <div class="tag"><?php echo htmlspecialchars(t('brand_tag')); ?></div>
        </div>
        <nav class="nav">
          <a href="#home"><?php echo htmlspecialchars(t('home')); ?></a>
          <a href="add.php" class="cta"><?php echo htmlspecialchars(t('add_listing')); ?></a>
          <a href="contact.php"><?php echo htmlspecialchars(t('contact')); ?></a>
          <a href="?lang=<?php echo $lang==='ar'?'en':'ar'; ?>" style="margin-left:12px"><?php echo $lang==='ar'?'EN':'AR'; ?></a>
        </nav>
      </div>
    </header>

    <main>
      <section class="hero container" id="home">
        <div class="hero-text">
          <h1><?php echo htmlspecialchars(t('hero_title')); ?></h1>
          <p><?php echo htmlspecialchars(t('hero_subtitle')); ?></p>
          <div class="hero-actions">
            <a class="btn primary" href="add.php"><?php echo htmlspecialchars(t('add_your_listing')); ?></a>
            <a class="btn ghost" href="#listings"><?php echo htmlspecialchars(t('browse_listings')); ?></a>
          </div>
        </div>
      </section>

      <section class="container listings" id="listings">
        <h2><?php echo htmlspecialchars(t('latest_listings')); ?></h2>
        <form method="get" class="form-inline" style="margin:12px 0 18px">
          <div class="inline-field">
            <label for="govSelect"><?php echo htmlspecialchars(t('governorate')); ?></label>
            <select id="govSelect" name="governorate">
              <option value=""><?php echo htmlspecialchars(t('all_governorates')); ?></option>
              <?php
                $loc_path = __DIR__ . '/assets/data/eg_locations.json';
                $loc_rel  = 'assets/data/eg_locations.json';
                $json_file = file_exists($loc_path) ? $loc_path : (file_exists($loc_rel) ? $loc_rel : null);
                $gov_list = array();
                if ($json_file) {
                  $json = @file_get_contents($json_file);
                  if ($json !== false) {
                    $arr = json_decode($json, true);
                    if (is_array($arr)) {
                      $dataset = $arr[$lang] ?? $arr['en'] ?? $arr;
                      if (is_array($dataset)) $gov_list = array_keys($dataset);
                    }
                  }
                }
                sort($gov_list);
                $selGov = $_GET['governorate'] ?? '';
                foreach ($gov_list as $g) {
                  $sel = ($selGov === $g) ? ' selected' : '';
                  echo '<option value="'.htmlspecialchars($g).'"'.$sel.'>'.htmlspecialchars($g)."</option>";
                }
              ?>
            </select>
          </div>
          <div class="inline-field">
            <label for="citySelect"><?php echo htmlspecialchars(t('city')); ?></label>
            <select id="citySelect" name="city">
              <option value=""><?php echo htmlspecialchars(t('all_cities')); ?></option>
            </select>
          </div>
          <div class="inline-field">
            <label for="q"><?php echo htmlspecialchars(t('keyword')); ?></label>
            <input id="q" name="q" value="<?php echo htmlspecialchars($_GET['q'] ?? ''); ?>" placeholder="<?php echo htmlspecialchars(t('keyword')); ?>" />
          </div>
          <button class="btn" type="submit"><?php echo htmlspecialchars(t('search')); ?></button>
        </form>
        <div class="list-grid">
          <?php
            $where = [];
            $qGov = trim($_GET['governorate'] ?? '');
            $qCity = trim($_GET['city'] ?? '');
            $qKey = trim($_GET['q'] ?? '');
            if ($qGov !== '') { $where[] = "governorate='" . $conn->real_escape_string($qGov) . "'"; }
            if ($qCity !== '') { $where[] = "city='" . $conn->real_escape_string($qCity) . "'"; }
            if ($qKey !== '') {
              $k = '%' . $conn->real_escape_string($qKey) . '%';
              $where[] = "(title LIKE '$k' OR description LIKE '$k')";
            }
            $sql = 'SELECT * FROM apartments';
            if (!empty($where)) { $sql .= ' WHERE ' . implode(' AND ', $where); }
            $sql .= ' ORDER BY id DESC LIMIT 100';
            $r = $conn->query($sql);
            if ($r && $r->num_rows > 0) {
              while ($row = $r->fetch_assoc()) {
          ?>
            <div class="list-item">
              <div class="left">
                <?php if (!empty($row['video_file']) && file_exists('uploads/videos/' . $row['video_file'])): ?>
                  <video muted playsinline>
                    <source src="uploads/videos/<?php echo htmlspecialchars($row['video_file']); ?>" type="video/mp4" />
                  </video>
                <?php else: ?>
                  <div class="img-placeholder small"></div>
                <?php endif; ?>
              </div>
              <div class="right">
                <h3><?php echo htmlspecialchars($row['title']); ?></h3>
                <p class="meta"><?php echo htmlspecialchars($row['governorate'] . ' - ' . $row['city']); ?></p>
                <p class="price"><?php echo number_format($row['price'], 2); ?> EGP</p>
                <div class="row-actions">
                  <a class="btn" href="view.php?id=<?php echo $row['id']; ?>"><?php echo htmlspecialchars(t('view')); ?></a>
                  <button class="btn ghost" type="button" onclick="toggleOwner('owner-<?php echo $row['id']; ?>')"><?php echo htmlspecialchars(t('connect_owner')); ?></button>
                </div>
                <div id="owner-<?php echo $row['id']; ?>" class="owner-box" style="display:none;margin-top:8px">
                  <div><strong><?php echo htmlspecialchars(t('owner')); ?>:</strong> <?php echo htmlspecialchars($row['owner_name']); ?></div>
                  <div><strong><?php echo htmlspecialchars(t('phone')); ?>:</strong> <a href="tel:<?php echo htmlspecialchars($row['phone']); ?>"><?php echo htmlspecialchars($row['phone']); ?></a></div>
                  <div><strong><?php echo htmlspecialchars(t('governorate')); ?> / <?php echo htmlspecialchars(t('city')); ?>:</strong> <?php echo htmlspecialchars($row['governorate'] . ' / ' . $row['city']); ?></div>
                </div>
              </div>
            </div>
          <?php
              }
            } else {
              echo '<p class="muted">No listings yet.</p>';
            }
          ?>
        </div>
      </section>
    </main>

    <footer class="foot">
      <div class="container">©<?php echo date('Y'); ?> <?php echo htmlspecialchars(t('site_name')); ?></div>
    </footer>

    <script src="assets/js/main.js?v=<?php echo time();?>"></script>
  </body>
</html>
