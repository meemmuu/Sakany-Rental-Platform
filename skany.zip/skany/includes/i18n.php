<?php
session_start();
if (isset($_GET['lang'])) {
  $_SESSION['lang'] = $_GET['lang'] === 'ar' ? 'ar' : 'en';
}
$lang = $_SESSION['lang'] ?? 'en';
$dir = $lang === 'ar' ? 'rtl' : 'ltr';

$t = array();
if ($lang === 'ar') {
  $t = array(
    'site_name' => 'سكني',
    'lang_code' => 'ar',
    'home' => 'الرئيسية',
    'add_listing' => 'أضف إعلان',
    'contact' => 'اتصل بنا',
    'brand_tag' => 'تأجير مباشر — من المالك للمستأجر',
    'add_your_listing' => 'أضف إعلانك',
    'owner_name' => 'اسم المالك',
    'phone' => 'الهاتف',
    'title' => 'العنوان',
    'description' => 'الوصف',
    'governorate' => 'المحافظة',
    'city' => 'المدينة / المركز',
    'price_egp' => 'السعر (جنيه)',
    'upload_video_opt' => 'رفع فيديو (اختياري)',
    'publish_listing' => 'نشر الإعلان',
    'contact_title' => 'اتصل بنا',
    'send_message' => 'إرسال الرسالة',
    'browse_listings' => 'تصفح الإعلانات',
    'search' => 'بحث',
    'keyword' => 'كلمة مفتاحية',
    'all_governorates' => 'كل المحافظات',
    'all_cities' => 'كل المدن',
    'latest_listings' => 'أحدث الإعلانات',
    'view' => 'عرض',
    'call' => 'اتصال',
    'connect_owner' => 'تواصل مع المالك',
    'owner' => 'المالك',
    'rented' => 'مؤجَّرة',
    'available' => 'متاحة',
    'contact_unavailable' => 'غير متاح للتواصل',
    'hero_title' => 'اعثر على منزلك التالي — مباشرة من المالك',
    'hero_subtitle' => 'بدون وسطاء. شاهد فيديو قصير وتواصل مع المالك فورًا.'
  );
} else {
  $t = array(
    'site_name' => 'Skany',
    'lang_code' => 'en',
    'home' => 'Home',
    'add_listing' => 'Add Listing',
    'contact' => 'Contact',
    'brand_tag' => 'Rent Direct — Owner to Tenant',
    'add_your_listing' => 'Add Your Listing',
    'owner_name' => 'Owner name',
    'phone' => 'Phone',
    'title' => 'Title',
    'description' => 'Description',
    'governorate' => 'Governorate',
    'city' => 'City',
    'price_egp' => 'Price (EGP)',
    'upload_video_opt' => 'Upload video (optional)',
    'publish_listing' => 'Publish Listing',
    'contact_title' => 'Contact',
    'send_message' => 'Send Message',
    'browse_listings' => 'Browse Listings',
    'search' => 'Search',
    'keyword' => 'Keyword',
    'all_governorates' => 'All governorates',
    'all_cities' => 'All cities',
    'latest_listings' => 'Latest Listings',
    'view' => 'View',
    'call' => 'Call',
    'connect_owner' => 'Connect with owner',
    'owner' => 'Owner',
    'rented' => 'Rented',
    'available' => 'Available',
    'contact_unavailable' => 'Contact unavailable',
    'hero_title' => 'Find your next home — directly from the owner',
    'hero_subtitle' => 'No middlemen. Watch a short video and contact the owner instantly.'
  );
}

function t($key) {
  global $t; return $t[$key] ?? $key;
}
?>